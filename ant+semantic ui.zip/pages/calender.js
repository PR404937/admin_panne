import React, { Component } from 'react'
import { Layout,  Breadcrumb } from 'antd';
const { Content,} = Layout;

export default class Home extends Component {
    render() {
        return (
              <Content style={{ margin: '0 16px' }}>
                 <Breadcrumb style={{ margin: '16px 0',backgroundColor:"grey",height:"30px"}}>
                  <Breadcrumb.Item style={{color:"black",marginLeft:"20px"}}>Callender</Breadcrumb.Item>
                  <Breadcrumb.Item>Bill</Breadcrumb.Item>
                </Breadcrumb>
                <div className="site-layout-background" style={{ padding: 24, minHeight: '80vh' }}>
                  <p>CALLENDER</p>
                </div>
              </Content>
        )
    }
}
