import React, { Component } from 'react'
import { Layout,  Breadcrumb } from 'antd';
const { Content,} = Layout;

export default class Home extends Component {
    render() {
        return (
              <Content style={{ margin: '0 16px'}}>
            
            <Breadcrumb style={{ margin: '16px 0',backgroundColor:"grey",height:"30px"}}>
                  <Breadcrumb.Item style={{color:"black",marginLeft:"20px"}}>Dashboard</Breadcrumb.Item>
                  <Breadcrumb.Item>Bill</Breadcrumb.Item>
                </Breadcrumb>
                <div className="site-layout-background" style={{ padding: 24, minHeight: '80vh'}}>
                  <center>
                    <br />
                    <br />
                    <br />
                    <br />
                    <br />
                    {/* <img src="https://www.freepnglogos.com/uploads/buddha-png/colourful-buddha-transparent-png-stickpng-28.png" width="260px" /> */}
                  </center>
                </div>
              </Content>
        )
    }
}
